import { Component, OnInit } from '@angular/core';
import { CourseService } from '../services/course.service';
export interface Course {
    image: string,
    title: string,
    content: string,
}
@Component({
    selector: 'app-course-comp',
    templateUrl: 'course.component.html',
    styleUrls: ['course.component.css'],
})


export class CourseComponent implements OnInit {
    slideIndex: Number;
    dots: any;
    captionText: String;
    currentSlide: any;
    currentIndex: number;
    slides:any;
    title = "HTML Assignment";
    courseTitle = "How we create unforgettable experiences";

    constructor(private _courseService: CourseService) {
        this._courseService = _courseService;
    }

    ngOnInit() {
        this._courseService.getCourses().subscribe(resp => {
            console.log(resp);
            if (resp) {
                this.slides = resp;
                this.currentIndex = 0;
                this.dots = this.slides;
                this.currentSlide = this.slides[this.currentIndex];
                this.slideIndex = this.currentIndex;
            }
        });
    }

    initiateCourse() {

    }

    nextSlide() {
        if (this.currentIndex < this.slides.length - 1) {
            this.currentIndex++;
            this.currentSlide = this.slides[this.currentIndex];
        }
    }

    prevSlide() {
        if (this.currentIndex > 0) {
            this.currentIndex--;
            this.currentSlide = this.slides[this.currentIndex];
        }
    }

    dotClick(index: number) {
        this.currentIndex = index;
        this.currentSlide = this.slides[this.currentIndex];

    }
}